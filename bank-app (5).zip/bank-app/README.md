# Banking System (OOAD-Java Assignment)

Layers: `view` (JavaFX boundary) -> `controller` (mediators) -> `model` (core logic) -> `dao` (JDBC / H2).

## Run
    mvn javafx:run                                            # GUI (open the Codespaces desktop on port 6080)
    mvn compile exec:java -Dexec.mainClass=bank.ConsoleDemo   # Week 4 model demo
    mvn compile exec:java -Dexec.mainClass=bank.DaoDemo       # Week 7 database demo
    mvn test                                                  # unit + DAO + integration tests (needs the desktop)

## Features
- Login, **register new customer** (individual or company), **open new account** (savings, investment, cheque)
- View balance and history, deposit, withdraw (rules enforced in the model, saved through JDBC)

## Demo logins
- thabo / pass123 (savings S1001, investment I2001, cheque CH3001)
- acme / acme123 (company: savings, investment)

The H2 file database lives in ./data/ (git-ignored). Delete that folder to reset it.

## Weekly commits
1. Core model            (src/main/java/bank/model)
2. GUI boundary classes  (src/main/java/bank/view)
3. Controllers           (src/main/java/bank/controller)
4. Database + DAOs       (src/main/java/bank/dao, src/main/resources/schema.sql)
5. Integration + tests   (src/test/java, TEST_REPORT)
