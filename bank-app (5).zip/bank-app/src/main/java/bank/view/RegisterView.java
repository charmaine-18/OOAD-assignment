package bank.view;

import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/** Boundary class: customer registration form. Collects input only; the controller validates it. */
public class RegisterView {
    private final VBox root = new VBox(14);
    private final GridPane grid = new GridPane();
    private int row = 0;

    private final ComboBox<String> typeCombo = new ComboBox<>();
    private final TextField usernameField = new TextField();
    private final PasswordField passwordField = new PasswordField();
    private final PasswordField confirmField = new PasswordField();
    private final TextField addressField = new TextField();
    private final TextField firstNameField = new TextField();
    private final TextField surnameField = new TextField();
    private final CheckBox employedCheck = new CheckBox("Currently employed");
    private final TextField companyNameField = new TextField();
    private final TextField registrationNoField = new TextField();
    private final Button registerButton = new Button("Register");
    private final Button backButton = new Button("Back to login");
    private final Label messageLabel = new Label();

    private final List<Node> individualNodes = new ArrayList<>();
    private final List<Node> companyNodes = new ArrayList<>();

    public RegisterView() {
        typeCombo.setId("typeCombo");
        usernameField.setId("usernameField");
        passwordField.setId("passwordField");
        confirmField.setId("confirmField");
        addressField.setId("addressField");
        firstNameField.setId("firstNameField");
        surnameField.setId("surnameField");
        employedCheck.setId("employedCheck");
        companyNameField.setId("companyNameField");
        registrationNoField.setId("registrationNoField");
        registerButton.setId("registerButton");
        backButton.setId("backButton");
        messageLabel.setId("messageLabel");

        Label title = new Label("Register as a new customer");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        typeCombo.getItems().addAll("Individual", "Company");
        typeCombo.setValue("Individual");

        grid.setHgap(12);
        grid.setVgap(10);
        addRow("Customer type", typeCombo, null);
        addRow("Username", usernameField, null);
        addRow("Password", passwordField, null);
        addRow("Confirm password", confirmField, null);
        addRow("Address", addressField, null);
        addRow("First name", firstNameField, individualNodes);
        addRow("Surname", surnameField, individualNodes);
        addRow("Employment", employedCheck, individualNodes);
        addRow("Company name", companyNameField, companyNodes);
        addRow("Registration no.", registrationNoField, companyNodes);

        showTypeFields(true);
        typeCombo.setOnAction(e -> showTypeFields("Individual".equals(typeCombo.getValue())));

        registerButton.setStyle("-fx-background-color: #2c5aa0; -fx-text-fill: white; -fx-font-weight: bold;");
        messageLabel.setWrapText(true);

        root.getChildren().addAll(title, grid, new HBox(10, registerButton, backButton), messageLabel);
        root.setPadding(new Insets(25));
    }

    private void addRow(String labelText, Node field, List<Node> group) {
        Label label = new Label(labelText);
        grid.add(label, 0, row);
        grid.add(field, 1, row);
        row++;
        if (group != null) {
            group.add(label);
            group.add(field);
        }
    }

    /** Pure display behaviour: show only the fields relevant to the chosen customer type. */
    private void showTypeFields(boolean individual) {
        individualNodes.forEach(n -> { n.setVisible(individual); n.setManaged(individual); });
        companyNodes.forEach(n -> { n.setVisible(!individual); n.setManaged(!individual); });
    }

    public Parent getRoot() { return root; }

    // ---------- input ----------
    public String getCustomerType() { return typeCombo.getValue(); }
    public String getUsername() { return usernameField.getText(); }
    public String getPassword() { return passwordField.getText(); }
    public String getConfirmPassword() { return confirmField.getText(); }
    public String getAddress() { return addressField.getText(); }
    public String getFirstName() { return firstNameField.getText(); }
    public String getSurname() { return surnameField.getText(); }
    public boolean isEmployed() { return employedCheck.isSelected(); }
    public String getCompanyName() { return companyNameField.getText(); }
    public String getRegistrationNo() { return registrationNoField.getText(); }

    // ---------- output ----------
    public void showMessage(String message, boolean isError) {
        messageLabel.setStyle(isError ? "-fx-text-fill: #c0392b;" : "-fx-text-fill: #27ae60;");
        messageLabel.setText(message);
    }

    public void clearForm() {
        usernameField.clear();
        passwordField.clear();
        confirmField.clear();
        addressField.clear();
        firstNameField.clear();
        surnameField.clear();
        employedCheck.setSelected(false);
        companyNameField.clear();
        registrationNoField.clear();
    }

    // ---------- events ----------
    public void setOnRegister(Runnable h) { registerButton.setOnAction(e -> h.run()); }
    public void setOnBack(Runnable h) { backButton.setOnAction(e -> h.run()); }
}
