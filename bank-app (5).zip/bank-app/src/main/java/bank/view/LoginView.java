package bank.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

/** Boundary class: shows the login screen and collects input. No business logic. */
public class LoginView {
    private final StackPane root = new StackPane();
    private final TextField usernameField = new TextField();
    private final PasswordField passwordField = new PasswordField();
    private final Button loginButton = new Button("Login");
    private final Hyperlink registerLink = new Hyperlink("New customer? Register here");
    private final Label messageLabel = new Label();

    public LoginView() {
        usernameField.setId("usernameField");
        passwordField.setId("passwordField");
        loginButton.setId("loginButton");
        messageLabel.setId("messageLabel");
        registerLink.setId("registerLink");

        Label title = new Label("Banking System");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
        Label subtitle = new Label("Please log in to continue");
        subtitle.setStyle("-fx-text-fill: #666666;");

        usernameField.setPromptText("Username");
        passwordField.setPromptText("Password");

        loginButton.setDefaultButton(true);          // Enter key triggers login
        loginButton.setMaxWidth(Double.MAX_VALUE);
        loginButton.setStyle("-fx-background-color: #2c5aa0; -fx-text-fill: white; -fx-font-weight: bold;");

        messageLabel.setWrapText(true);
        messageLabel.setStyle("-fx-text-fill: #c0392b;");

        VBox form = new VBox(12, title, subtitle, usernameField, passwordField, loginButton, registerLink, messageLabel);
        form.setAlignment(Pos.CENTER_LEFT);
        form.setMaxWidth(320);

        root.setPadding(new Insets(30));
        root.getChildren().add(form);
    }

    public Parent getRoot() { return root; }

    public String getUsername() { return usernameField.getText(); }
    public String getPassword() { return passwordField.getText(); }

    public void showError(String message) { messageLabel.setText(message); }
    public void clearPassword() { passwordField.clear(); }

    /** The controller registers what should happen when the user clicks Login. */
    public void setOnLogin(Runnable handler) { loginButton.setOnAction(e -> handler.run()); }
    public void setOnRegister(Runnable handler) { registerLink.setOnAction(e -> handler.run()); }
}
