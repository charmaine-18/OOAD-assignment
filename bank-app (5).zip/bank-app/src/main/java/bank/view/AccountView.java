package bank.view;

import java.util.List;

import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

/**
 * Boundary class: shows a customer's accounts, balance and history, and collects
 * deposit/withdraw input. It receives ready-made strings from the controller and
 * never touches model classes or business rules.
 */
public class AccountView {

    /** Plain display row so the view does not depend on the model. */
    public record TransactionRow(String id, String date, String type, String amount, String balanceAfter) { }

    private final BorderPane root = new BorderPane();
    private final Label welcomeLabel = new Label();
    private final Button openAccountButton = new Button("Open new account");
    private final Button logoutButton = new Button("Logout");
    private final ComboBox<String> accountCombo = new ComboBox<>();
    private final Label typeLabel = new Label("-");
    private final Label balanceLabel = new Label("-");
    private final TableView<TransactionRow> historyTable = new TableView<>();
    private final TextField amountField = new TextField();
    private final Button depositButton = new Button("Deposit");
    private final Button withdrawButton = new Button("Withdraw");
    private final Label messageLabel = new Label();

    public AccountView() {
        welcomeLabel.setId("welcomeLabel");
        logoutButton.setId("logoutButton");
        openAccountButton.setId("openAccountButton");
        accountCombo.setId("accountCombo");
        typeLabel.setId("typeLabel");
        balanceLabel.setId("balanceLabel");
        historyTable.setId("historyTable");
        amountField.setId("amountField");
        depositButton.setId("depositButton");
        withdrawButton.setId("withdrawButton");
        messageLabel.setId("messageLabel");

        // ---- Top bar ----
        welcomeLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox topBar = new HBox(10, welcomeLabel, spacer, openAccountButton, logoutButton);
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setPadding(new Insets(0, 0, 15, 0));

        // ---- Account selection + balance ----
        accountCombo.setPromptText("Select an account");
        accountCombo.setMaxWidth(Double.MAX_VALUE);
        typeLabel.setStyle("-fx-font-size: 14px;");
        balanceLabel.setStyle("-fx-font-size: 26px; -fx-font-weight: bold; -fx-text-fill: #2c5aa0;");
        VBox balanceBox = new VBox(4, new Label("Account type"), typeLabel,
                new Label("Current balance"), balanceLabel);
        balanceBox.setPadding(new Insets(10));
        balanceBox.setStyle("-fx-background-color: #f2f5fa; -fx-background-radius: 6;");

        // ---- Transaction history ----
        historyTable.getColumns().add(column("ID", 50, TransactionRow::id));
        historyTable.getColumns().add(column("Date", 100, TransactionRow::date));
        historyTable.getColumns().add(column("Type", 110, TransactionRow::type));
        historyTable.getColumns().add(column("Amount", 100, TransactionRow::amount));
        historyTable.getColumns().add(column("Balance after", 120, TransactionRow::balanceAfter));
        historyTable.setPlaceholder(new Label("No transactions yet"));
        VBox.setVgrow(historyTable, Priority.ALWAYS);

        VBox center = new VBox(10, new Label("Your accounts"), accountCombo, balanceBox,
                new Label("Transaction history"), historyTable);

        // ---- Bottom: amount entry + actions ----
        amountField.setPromptText("Amount (BWP)");
        depositButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-weight: bold;");
        withdrawButton.setStyle("-fx-background-color: #c0392b; -fx-text-fill: white; -fx-font-weight: bold;");
        HBox actions = new HBox(10, amountField, depositButton, withdrawButton);
        actions.setAlignment(Pos.CENTER_LEFT);
        messageLabel.setWrapText(true);
        VBox bottom = new VBox(8, actions, messageLabel);
        bottom.setPadding(new Insets(15, 0, 0, 0));

        root.setTop(topBar);
        root.setCenter(center);
        root.setBottom(bottom);
        root.setPadding(new Insets(20));
    }

    private static TableColumn<TransactionRow, String> column(String title, double width,
            java.util.function.Function<TransactionRow, String> getter) {
        TableColumn<TransactionRow, String> col = new TableColumn<>(title);
        col.setPrefWidth(width);
        col.setCellValueFactory(data -> new SimpleStringProperty(getter.apply(data.getValue())));
        return col;
    }

    public Parent getRoot() { return root; }

    // ---------- Display methods (called by the controller) ----------
    public void setWelcome(String text) { welcomeLabel.setText(text); }

    public void setAccounts(List<String> labels, int selectedIndex) {
        accountCombo.getItems().setAll(labels);
        if (selectedIndex >= 0 && selectedIndex < labels.size()) {
            accountCombo.getSelectionModel().select(selectedIndex);
        }
    }

    public void setAccountDetails(String accountType, String balanceText) {
        typeLabel.setText(accountType);
        balanceLabel.setText(balanceText);
    }

    public void setTransactions(List<TransactionRow> rows) { historyTable.getItems().setAll(rows); }
    public void setWithdrawEnabled(boolean enabled) { withdrawButton.setDisable(!enabled); }
    public void clearAmount() { amountField.clear(); }

    public void showMessage(String message, boolean isError) {
        messageLabel.setStyle(isError ? "-fx-text-fill: #c0392b;" : "-fx-text-fill: #27ae60;");
        messageLabel.setText(message);
    }

    // ---------- Input methods (read by the controller) ----------
    public String getAmountText() { return amountField.getText(); }
    public int getSelectedIndex() { return accountCombo.getSelectionModel().getSelectedIndex(); }

    // ---------- Event registration (controller decides what happens) ----------
    public void setOnAccountSelected(Runnable h) { accountCombo.setOnAction(e -> h.run()); }
    public void setOnDeposit(Runnable h) { depositButton.setOnAction(e -> h.run()); }
    public void setOnWithdraw(Runnable h) { withdrawButton.setOnAction(e -> h.run()); }
    public void setOnLogout(Runnable h) { logoutButton.setOnAction(e -> h.run()); }
    public void setOnOpenAccount(Runnable h) { openAccountButton.setOnAction(e -> h.run()); }
}
