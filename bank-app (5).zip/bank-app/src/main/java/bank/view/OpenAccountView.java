package bank.view;

import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/** Boundary class: form for opening a new account. Collects input only; rules live in the model. */
public class OpenAccountView {
    private final VBox root = new VBox(14);
    private final GridPane grid = new GridPane();
    private int row = 0;

    private final ComboBox<String> typeCombo = new ComboBox<>();
    private final TextField branchField = new TextField();
    private final TextField amountField = new TextField();
    private final Label hintLabel = new Label();
    private final TextField employerNameField = new TextField();
    private final TextField employerAddressField = new TextField();
    private final Button openButton = new Button("Open account");
    private final Button backButton = new Button("Back to accounts");
    private final Label messageLabel = new Label();

    private final List<Node> employerNodes = new ArrayList<>();
    private Runnable typeChangedHandler;

    public OpenAccountView() {
        typeCombo.setId("typeCombo");
        branchField.setId("branchField");
        amountField.setId("amountField");
        hintLabel.setId("hintLabel");
        employerNameField.setId("employerNameField");
        employerAddressField.setId("employerAddressField");
        openButton.setId("openButton");
        backButton.setId("backButton");
        messageLabel.setId("messageLabel");

        Label title = new Label("Open a new account");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        typeCombo.getItems().addAll("Savings", "Investment", "Cheque");
        typeCombo.setValue("Savings");
        amountField.setPromptText("Opening deposit (BWP)");
        hintLabel.setStyle("-fx-text-fill: #666666;");
        hintLabel.setWrapText(true);

        grid.setHgap(12);
        grid.setVgap(10);
        addRow("Account type", typeCombo, null);
        addRow("Branch", branchField, null);
        addRow("Opening deposit", amountField, null);
        grid.add(hintLabel, 1, row++);
        addRow("Employer name", employerNameField, employerNodes);
        addRow("Employer address", employerAddressField, employerNodes);

        setEmployerFieldsVisible(false);
        typeCombo.setOnAction(e -> {
            setEmployerFieldsVisible("Cheque".equals(typeCombo.getValue()));
            if (typeChangedHandler != null) {
                typeChangedHandler.run();
            }
        });

        openButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-weight: bold;");
        messageLabel.setWrapText(true);

        root.getChildren().addAll(title, grid, new HBox(10, openButton, backButton), messageLabel);
        root.setPadding(new Insets(25));
    }

    private void addRow(String labelText, Node field, List<Node> group) {
        Label label = new Label(labelText);
        grid.add(label, 0, row);
        grid.add(field, 1, row);
        row++;
        if (group != null) {
            group.add(label);
            group.add(field);
        }
    }

    public Parent getRoot() { return root; }

    // ---------- display ----------
    public void setEmployerFieldsVisible(boolean visible) {
        employerNodes.forEach(n -> { n.setVisible(visible); n.setManaged(visible); });
    }

    public void setHint(String hint) { hintLabel.setText(hint); }

    public void showMessage(String message, boolean isError) {
        messageLabel.setStyle(isError ? "-fx-text-fill: #c0392b;" : "-fx-text-fill: #27ae60;");
        messageLabel.setText(message);
    }

    public void clearForm() {
        amountField.clear();
        employerNameField.clear();
        employerAddressField.clear();
    }

    // ---------- input ----------
    public String getAccountType() { return typeCombo.getValue(); }
    public String getBranch() { return branchField.getText(); }
    public String getAmountText() { return amountField.getText(); }
    public String getEmployerName() { return employerNameField.getText(); }
    public String getEmployerAddress() { return employerAddressField.getText(); }

    // ---------- events ----------
    public void setOnOpen(Runnable h) { openButton.setOnAction(e -> h.run()); }
    public void setOnBack(Runnable h) { backButton.setOnAction(e -> h.run()); }
    public void setOnTypeChanged(Runnable h) { this.typeChangedHandler = h; }
}
