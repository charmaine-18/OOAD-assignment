package bank.controller;

import bank.dao.DataAccessException;
import bank.model.*;
import bank.view.OpenAccountView;

/** Validates the open-account form, creates the right Account subclass and saves it. */
public class OpenAccountController {
    private final OpenAccountView view;
    private final AppContext context;

    public OpenAccountController(OpenAccountView view, AppContext context, Runnable onBack) {
        this.view = view;
        this.context = context;
        view.setOnOpen(this::handleOpen);
        view.setOnBack(onBack);
        view.setOnTypeChanged(this::updateHint);
        updateHint();
    }

    private void updateHint() {
        String type = view.getAccountType();
        if ("Investment".equals(type)) {
            view.setHint(String.format("Minimum opening deposit: BWP %.2f", InvestmentAccount.MIN_OPENING));
        } else if ("Cheque".equals(type)) {
            view.setHint("Employer details are required.");
        } else {
            view.setHint("");
        }
    }

    private void handleOpen() {
        Customer customer = context.getCurrentCustomer();
        String type = view.getAccountType();
        String branch = trim(view.getBranch());
        String amountText = trim(view.getAmountText());

        // ----- input validation -----
        if (type == null) {
            view.showMessage("Please choose an account type.", true);
            return;
        }
        if (branch.isEmpty()) {
            view.showMessage("Please enter the branch.", true);
            return;
        }
        if (amountText.isEmpty()) {
            view.showMessage("Please enter an opening deposit.", true);
            return;
        }
        double amount;
        try {
            amount = Double.parseDouble(amountText);
            if (Double.isNaN(amount) || Double.isInfinite(amount)) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            view.showMessage("Amount must be a number, e.g. 150.00", true);
            return;
        }
        String employerName = trim(view.getEmployerName());
        if ("Cheque".equals(type) && employerName.isEmpty()) {
            view.showMessage("Employer name is required for a cheque account.", true);
            return;
        }

        // ----- create the account (model rules apply) and save it (DAO) -----
        try {
            String number = context.nextAccountNumber(type);
            Account account = switch (type) {
                case "Savings" -> new SavingsAccount(number, branch, amount);
                case "Investment" -> new InvestmentAccount(number, branch, amount);
                case "Cheque" -> new ChequeAccount(number, branch, amount,
                        new Employer(employerName, trim(view.getEmployerAddress())));
                default -> throw new IllegalArgumentException("Please choose an account type.");
            };
            context.getAccountDAO().insert(customer.getCustomerId(), account);
            customer.addAccount(account);
            view.showMessage(String.format("Account %s opened successfully with BWP %.2f.", number, amount), false);
            view.clearForm();
        } catch (IllegalArgumentException e) {
            view.showMessage(e.getMessage(), true);
        } catch (DataAccessException e) {
            view.showMessage("The account could not be saved. Please try again.", true);
        }
    }

    private static String trim(String s) {
        return s == null ? "" : s.trim();
    }
}
