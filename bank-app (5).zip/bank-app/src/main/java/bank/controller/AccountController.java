package bank.controller;

import java.util.ArrayList;
import java.util.List;

import bank.dao.DataAccessException;
import bank.model.*;
import bank.view.AccountView;
import bank.view.AccountView.TransactionRow;

/** Mediates between AccountView and the Account model: handles deposit, withdraw and display. */
public class AccountController {
    private final AccountView view;
    private final AppContext context;
    private final Runnable onLogout;
    private final Runnable onOpenAccount;

    public AccountController(AccountView view, AppContext context, Runnable onLogout) {
        this(view, context, onLogout, () -> { });
    }

    public AccountController(AccountView view, AppContext context, Runnable onLogout, Runnable onOpenAccount) {
        this.view = view;
        this.context = context;
        this.onLogout = onLogout;
        this.onOpenAccount = onOpenAccount;

        view.setOnAccountSelected(this::showSelectedAccount);
        view.setOnDeposit(this::handleDeposit);
        view.setOnWithdraw(this::handleWithdraw);
        view.setOnLogout(this::handleLogout);
        view.setOnOpenAccount(onOpenAccount);

        loadCustomer();
    }

    private void loadCustomer() {
        Customer customer = context.getCurrentCustomer();
        view.setWelcome("Welcome, " + displayName(customer));

        List<String> labels = new ArrayList<>();
        for (Account a : customer.getAccounts()) {
            labels.add(a.getAccountNumber() + " - " + a.getAccountType());
        }
        view.setAccounts(labels, 0);
        showSelectedAccount();
    }

    private void showSelectedAccount() {
        Account account = selectedAccount();
        if (account == null) {
            view.setAccountDetails("-", "-");
            view.setTransactions(new ArrayList<>());
            view.setWithdrawEnabled(false);
            view.showMessage("You have no accounts yet. Click \"Open new account\" to create one.", false);
            return;
        }
        view.setAccountDetails(account.getAccountType() + " (" + account.getBranch() + ")",
                money(account.getBalance()));

        List<TransactionRow> rows = new ArrayList<>();
        for (Transaction t : account.getTransactions()) {
            rows.add(new TransactionRow(String.valueOf(t.getTransactionId()), t.getDate().toString(),
                    t.getType(), money(t.getAmount()), money(t.getBalanceAfter())));
        }
        view.setTransactions(rows);
        view.setWithdrawEnabled(account instanceof Withdrawable);   // savings accounts cannot withdraw
    }

    private void handleDeposit() {
        Account account = selectedAccount();
        if (account == null) {
            view.showMessage("Please open an account first.", true);
            return;
        }
        Double amount = readAmount();
        if (amount == null) {
            return;
        }
        try {
            account.deposit(amount);                     // business rule (model)
            context.getAccountDAO().update(account);     // persistence (JDBC)
            view.showMessage("Deposited " + money(amount) + " successfully.", false);
            view.clearAmount();
            showSelectedAccount();
        } catch (IllegalArgumentException e) {
            view.showMessage(e.getMessage(), true);
        } catch (DataAccessException e) {
            view.showMessage("The deposit could not be saved. Please try again.", true);
        }
    }

    private void handleWithdraw() {
        Account account = selectedAccount();
        if (account == null) {
            view.showMessage("Please open an account first.", true);
            return;
        }
        Double amount = readAmount();
        if (amount == null) {
            return;
        }
        if (!(account instanceof Withdrawable withdrawable)) {
            view.showMessage("Withdrawals are not allowed on this account type.", true);
            return;
        }
        try {
            withdrawable.withdraw(amount);               // business rule (model)
            context.getAccountDAO().update(account);     // persistence (JDBC)
            view.showMessage("Withdrew " + money(amount) + " successfully.", false);
            view.clearAmount();
            showSelectedAccount();
        } catch (InsufficientFundsException | IllegalArgumentException e) {
            view.showMessage(e.getMessage(), true);
        } catch (DataAccessException e) {
            view.showMessage("The withdrawal could not be saved. Please try again.", true);
        }
    }

    private void handleLogout() {
        context.logout();
        onLogout.run();
    }

    // ---------- helpers ----------
    private Account selectedAccount() {
        List<Account> accounts = context.getCurrentCustomer().getAccounts();
        int index = view.getSelectedIndex();
        return (index >= 0 && index < accounts.size()) ? accounts.get(index) : null;
    }

    /** Validates the amount text; returns null (after showing a message) if invalid. */
    private Double readAmount() {
        String text = view.getAmountText() == null ? "" : view.getAmountText().trim();
        if (text.isEmpty()) {
            view.showMessage("Please enter an amount.", true);
            return null;
        }
        try {
            double value = Double.parseDouble(text);
            if (Double.isNaN(value) || Double.isInfinite(value)) {
                throw new NumberFormatException();
            }
            return value;
        } catch (NumberFormatException e) {
            view.showMessage("Amount must be a number, e.g. 150.00", true);
            return null;
        }
    }

    private static String displayName(Customer c) {
        if (c instanceof IndividualCustomer ind) {
            return ind.getFirstName() + " " + ind.getSurname();
        }
        if (c instanceof CompanyCustomer co) {
            return co.getCompanyName();
        }
        return c.getUsername();
    }

    private static String money(double value) {
        return String.format("BWP %.2f", value);
    }
}
