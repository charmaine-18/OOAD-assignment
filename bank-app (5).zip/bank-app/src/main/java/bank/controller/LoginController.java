package bank.controller;

import bank.dao.DataAccessException;
import bank.model.Customer;
import bank.view.LoginView;

/** Mediates between LoginView and the Customer model: validates input and checks credentials. */
public class LoginController {
    private final LoginView view;
    private final AppContext context;
    private final Runnable onLoginSuccess;

    public LoginController(LoginView view, AppContext context, Runnable onLoginSuccess) {
        this(view, context, onLoginSuccess, () -> { });
    }

    public LoginController(LoginView view, AppContext context, Runnable onLoginSuccess, Runnable onRegister) {
        this.view = view;
        this.context = context;
        this.onLoginSuccess = onLoginSuccess;
        view.setOnLogin(this::handleLogin);
        view.setOnRegister(onRegister);
    }

    private void handleLogin() {
        String username = view.getUsername() == null ? "" : view.getUsername().trim();
        String password = view.getPassword() == null ? "" : view.getPassword();

        // Input validation
        if (username.isEmpty() || password.isEmpty()) {
            view.showError("Please enter both username and password.");
            return;
        }

        // Business logic stays in the model: Customer.login(pw)
        Customer customer;
        try {
            customer = context.findByUsername(username);
        } catch (DataAccessException e) {
            view.showError("Could not reach the database. Please try again.");
            return;
        }
        if (customer == null || !customer.login(password)) {
            view.showError("Invalid username or password.");
            view.clearPassword();
            return;
        }

        context.setCurrentCustomer(customer);
        onLoginSuccess.run();
    }
}
