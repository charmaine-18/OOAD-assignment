package bank.controller;

import bank.dao.DataAccessException;
import bank.model.CompanyCustomer;
import bank.model.Customer;
import bank.model.IndividualCustomer;
import bank.view.RegisterView;

/** Validates the registration form, builds the Customer model object and saves it. */
public class RegisterController {
    private final RegisterView view;
    private final AppContext context;

    public RegisterController(RegisterView view, AppContext context, Runnable onBack) {
        this.view = view;
        this.context = context;
        view.setOnRegister(this::handleRegister);
        view.setOnBack(onBack);
    }

    private void handleRegister() {
        String type = view.getCustomerType();
        String username = trim(view.getUsername());
        String password = view.getPassword() == null ? "" : view.getPassword();
        String confirm = view.getConfirmPassword() == null ? "" : view.getConfirmPassword();
        String address = trim(view.getAddress());

        // ----- input validation -----
        if (username.isEmpty() || password.isEmpty() || address.isEmpty()) {
            view.showMessage("Please fill in all required fields.", true);
            return;
        }
        boolean company = "Company".equals(type);
        if (company) {
            if (trim(view.getCompanyName()).isEmpty() || trim(view.getRegistrationNo()).isEmpty()) {
                view.showMessage("Please fill in all required fields.", true);
                return;
            }
        } else if (trim(view.getFirstName()).isEmpty() || trim(view.getSurname()).isEmpty()) {
            view.showMessage("Please fill in all required fields.", true);
            return;
        }
        if (username.length() < 3 || username.contains(" ")) {
            view.showMessage("Username must be at least 3 characters with no spaces.", true);
            return;
        }
        if (password.length() < 6) {
            view.showMessage("Password must be at least 6 characters.", true);
            return;
        }
        if (!password.equals(confirm)) {
            view.showMessage("Passwords do not match.", true);
            return;
        }

        // ----- create the customer (model) and save it (DAO) -----
        try {
            if (context.usernameExists(username)) {
                view.showMessage("That username is already taken.", true);
                return;
            }
            String id = context.nextCustomerId();
            Customer customer = company
                    ? new CompanyCustomer(id, address, username, password,
                            trim(view.getCompanyName()), trim(view.getRegistrationNo()))
                    : new IndividualCustomer(id, address, username, password,
                            trim(view.getFirstName()), trim(view.getSurname()), view.isEmployed());
            context.saveCustomer(customer);
            view.showMessage("Registration successful! Your customer ID is " + id
                    + ". You can now log in.", false);
            view.clearForm();
        } catch (DataAccessException e) {
            view.showMessage("Registration failed because the database could not be reached.", true);
        }
    }

    private static String trim(String s) {
        return s == null ? "" : s.trim();
    }
}
