package bank.controller;

import bank.dao.AccountDAO;
import bank.dao.CustomerDAO;
import bank.model.Customer;

/** Holds the DAOs (persistence) and the currently logged-in customer. */
public class AppContext {
    private final CustomerDAO customerDAO;
    private final AccountDAO accountDAO;
    private Customer currentCustomer;

    public AppContext() {
        this(new CustomerDAO(), new AccountDAO());
    }

    public AppContext(CustomerDAO customerDAO, AccountDAO accountDAO) {
        this.customerDAO = customerDAO;
        this.accountDAO = accountDAO;
    }

    /** Loads the customer (with accounts and transactions) from the database. */
    public Customer findByUsername(String username) {
        return customerDAO.findByUsername(username);
    }

    public boolean usernameExists(String username) { return customerDAO.findByUsername(username) != null; }
    public String nextCustomerId() { return customerDAO.nextId(); }
    public void saveCustomer(Customer customer) { customerDAO.insert(customer); }
    public String nextAccountNumber(String accountType) { return accountDAO.nextAccountNumber(accountType); }

    public AccountDAO getAccountDAO() { return accountDAO; }

    public Customer getCurrentCustomer() { return currentCustomer; }
    public void setCurrentCustomer(Customer customer) { this.currentCustomer = customer; }
    public void logout() { this.currentCustomer = null; }
}
