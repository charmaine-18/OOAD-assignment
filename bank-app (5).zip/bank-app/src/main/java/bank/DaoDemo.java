package bank;

import bank.dao.*;
import bank.model.*;

/** Console check of the JDBC layer using a throw-away in-memory H2 database. */
public class DaoDemo {
    public static void main(String[] args) {
        DatabaseManager.setUrl("jdbc:h2:mem:demo;DB_CLOSE_DELAY=-1");
        DatabaseManager.initialise();
        DatabaseSeeder.seedIfEmpty();

        CustomerDAO customerDAO = new CustomerDAO();
        AccountDAO accountDAO = new AccountDAO();

        Customer thabo = customerDAO.findByUsername("thabo");
        System.out.println("Loaded: " + thabo.getUsername() + " (" + thabo.getCustomerType() + "), "
                + thabo.getAccounts().size() + " accounts, login ok? " + thabo.login("pass123"));

        Account savings = thabo.getAccounts().stream()
                .filter(a -> a instanceof SavingsAccount).findFirst().orElseThrow();
        System.out.printf("Before: %s balance %.2f, %d transactions%n",
                savings.getAccountNumber(), savings.getBalance(), savings.getTransactions().size());

        savings.deposit(100);
        accountDAO.update(savings);

        Account reloaded = accountDAO.findByNumber(savings.getAccountNumber());
        System.out.printf("After reload: balance %.2f, %d transactions%n",
                reloaded.getBalance(), reloaded.getTransactions().size());
        reloaded.getTransactions().forEach(t -> System.out.println("  " + t));

        System.out.println("All customers in DB: " + customerDAO.findAll().size());
        customerDAO.delete("C002");
        System.out.println("After deleting C002: " + customerDAO.findAll().size());
    }
}
