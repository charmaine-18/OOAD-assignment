package bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bank.model.Transaction;

public class TransactionDAO {

    /** Insert or update (MERGE) a transaction, so saving the same one twice is harmless. */
    void save(Connection c, String accountNumber, Transaction t) throws SQLException {
        String sql = "MERGE INTO bank_transaction "
                + "(transaction_id, account_number, tx_date, tx_type, amount, balance_after) "
                + "KEY (transaction_id) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, t.getTransactionId());
            ps.setString(2, accountNumber);
            ps.setDate(3, Date.valueOf(t.getDate()));
            ps.setString(4, t.getType());
            ps.setDouble(5, t.getAmount());
            ps.setDouble(6, t.getBalanceAfter());
            ps.executeUpdate();
        }
    }

    List<Transaction> findByAccount(Connection c, String accountNumber) throws SQLException {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT * FROM bank_transaction WHERE account_number = ? ORDER BY transaction_id";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, accountNumber);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Transaction(rs.getInt("transaction_id"), rs.getDate("tx_date").toLocalDate(),
                            rs.getString("tx_type"), rs.getDouble("amount"), rs.getDouble("balance_after")));
                }
            }
        }
        return list;
    }

    public List<Transaction> findByAccount(String accountNumber) {
        try (Connection c = DatabaseManager.getConnection()) {
            return findByAccount(c, accountNumber);
        } catch (SQLException e) {
            throw new DataAccessException("Could not load transactions for " + accountNumber, e);
        }
    }

    public int maxId() {
        try (Connection c = DatabaseManager.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT COALESCE(MAX(transaction_id), 0) FROM bank_transaction");
             ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        } catch (SQLException e) {
            throw new DataAccessException("Could not read the highest transaction id", e);
        }
    }
}
