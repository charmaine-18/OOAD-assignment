package bank.dao;

/** Unchecked wrapper so controllers do not have to handle SQLException. */
public class DataAccessException extends RuntimeException {
    public DataAccessException(String message, Throwable cause) {
        super(message, cause);
    }
}
