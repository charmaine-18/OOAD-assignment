package bank.dao;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/** Creates JDBC connections to the H2 database and builds the schema. */
public final class DatabaseManager {
    // File-based H2 database: data survives restarts (stored in ./data/). Tests can switch to in-memory.
    private static String url = "jdbc:h2:./data/bank";
    private static final String USER = "sa";
    private static final String PASSWORD = "";

    private DatabaseManager() { }

    public static void setUrl(String newUrl) { url = newUrl; }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, USER, PASSWORD);
    }

    /** H2-specific: wipes every table, then rebuilds the schema. Used by tests to start clean. */
    public static void resetDatabase() {
        try (Connection c = getConnection(); Statement st = c.createStatement()) {
            st.execute("DROP ALL OBJECTS");
        } catch (SQLException e) {
            throw new DataAccessException("Could not reset the database", e);
        }
        initialise();
    }

    /** Runs schema.sql (safe to call repeatedly: tables use CREATE TABLE IF NOT EXISTS). */
    public static void initialise() {
        try (InputStream in = DatabaseManager.class.getResourceAsStream("/schema.sql")) {
            if (in == null) {
                throw new DataAccessException("schema.sql not found on the classpath", null);
            }
            StringBuilder script = new StringBuilder();
            for (String line : new String(in.readAllBytes(), StandardCharsets.UTF_8).split("\n")) {
                if (!line.trim().startsWith("--")) {
                    script.append(line).append('\n');
                }
            }
            try (Connection c = getConnection(); Statement st = c.createStatement()) {
                for (String sql : script.toString().split(";")) {
                    if (!sql.trim().isEmpty()) {
                        st.execute(sql);
                    }
                }
            }
        } catch (IOException | SQLException e) {
            throw new DataAccessException("Could not initialise the database", e);
        }
    }
}
