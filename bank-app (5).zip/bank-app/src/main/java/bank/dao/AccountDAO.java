package bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import bank.model.*;

/** CRUD for accounts (and, through them, their transactions and cheque-account employer). */
public class AccountDAO {
    private static final String SELECT_ACCOUNT =
            "SELECT a.*, e.company_name, e.company_address "
            + "FROM account a LEFT JOIN employer e ON a.employer_id = e.employer_id ";

    private final TransactionDAO transactionDAO = new TransactionDAO();

    // ---------------- CREATE ----------------
    public void insert(String customerId, Account account) {
        try (Connection c = DatabaseManager.getConnection()) {
            c.setAutoCommit(false);
            try {
                Integer employerId = null;
                if (account instanceof ChequeAccount cheque) {
                    employerId = insertEmployer(c, cheque.getEmployer());
                }
                String sql = "INSERT INTO account (account_number, account_type, balance, branch, open_date, "
                        + "customer_id, employer_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement ps = c.prepareStatement(sql)) {
                    ps.setString(1, account.getAccountNumber());
                    ps.setString(2, account.getAccountType());
                    ps.setDouble(3, account.getBalance());
                    ps.setString(4, account.getBranch());
                    ps.setDate(5, Date.valueOf(account.getOpenDate()));
                    ps.setString(6, customerId);
                    if (employerId == null) {
                        ps.setNull(7, Types.INTEGER);
                    } else {
                        ps.setInt(7, employerId);
                    }
                    ps.executeUpdate();
                }
                for (Transaction t : account.getTransactions()) {
                    transactionDAO.save(c, account.getAccountNumber(), t);
                }
                c.commit();
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new DataAccessException("Could not insert account " + account.getAccountNumber(), e);
        }
    }

    private int insertEmployer(Connection c, Employer employer) throws SQLException {
        String sql = "INSERT INTO employer (company_name, company_address) VALUES (?, ?)";
        try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, employer.getCompanyName());
            ps.setString(2, employer.getCompanyAddress());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        }
    }

    // ---------------- READ ----------------
    public Account findByNumber(String accountNumber) {
        try (Connection c = DatabaseManager.getConnection();
             PreparedStatement ps = c.prepareStatement(SELECT_ACCOUNT + "WHERE a.account_number = ?")) {
            ps.setString(1, accountNumber);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapRow(c, rs) : null;
            }
        } catch (SQLException e) {
            throw new DataAccessException("Could not load account " + accountNumber, e);
        }
    }

    public List<Account> findByCustomerId(String customerId) {
        List<Account> accounts = new ArrayList<>();
        try (Connection c = DatabaseManager.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     SELECT_ACCOUNT + "WHERE a.customer_id = ? ORDER BY a.account_number")) {
            ps.setString(1, customerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    accounts.add(mapRow(c, rs));
                }
            }
        } catch (SQLException e) {
            throw new DataAccessException("Could not load accounts for customer " + customerId, e);
        }
        return accounts;
    }

    private Account mapRow(Connection c, ResultSet rs) throws SQLException {
        String type = rs.getString("account_type");
        String number = rs.getString("account_number");
        String branch = rs.getString("branch");
        double balance = rs.getDouble("balance");
        LocalDate openDate = rs.getDate("open_date").toLocalDate();
        List<Transaction> transactions = transactionDAO.findByAccount(c, number);

        return switch (type) {
            case "Savings" -> new SavingsAccount(number, branch, balance, openDate, transactions);
            case "Investment" -> new InvestmentAccount(number, branch, balance, openDate, transactions);
            case "Cheque" -> new ChequeAccount(number, branch, balance, openDate, transactions,
                    new Employer(rs.getString("company_name"), rs.getString("company_address")));
            default -> throw new IllegalStateException("Unknown account type: " + type);
        };
    }

    /** Next free account number for the type: S1003, I2003 or CH3002 style. */
    public String nextAccountNumber(String accountType) {
        String prefix;
        int highest;
        if ("Savings".equals(accountType)) {
            prefix = "S";
            highest = 1000;
        } else if ("Investment".equals(accountType)) {
            prefix = "I";
            highest = 2000;
        } else if ("Cheque".equals(accountType)) {
            prefix = "CH";
            highest = 3000;
        } else {
            throw new IllegalArgumentException("Unknown account type: " + accountType);
        }
        try (Connection c = DatabaseManager.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT account_number FROM account WHERE account_type = ?")) {
            ps.setString(1, accountType);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String digits = rs.getString(1).substring(prefix.length());
                    if (digits.matches("\\d+")) {
                        highest = Math.max(highest, Integer.parseInt(digits));
                    }
                }
            }
        } catch (SQLException e) {
            throw new DataAccessException("Could not generate an account number", e);
        }
        return prefix + (highest + 1);
    }

    // ---------------- UPDATE ----------------
    /** Saves the new balance and any new transactions in one database transaction. */
    public void update(Account account) {
        try (Connection c = DatabaseManager.getConnection()) {
            c.setAutoCommit(false);
            try {
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE account SET balance = ?, branch = ? WHERE account_number = ?")) {
                    ps.setDouble(1, account.getBalance());
                    ps.setString(2, account.getBranch());
                    ps.setString(3, account.getAccountNumber());
                    ps.executeUpdate();
                }
                for (Transaction t : account.getTransactions()) {
                    transactionDAO.save(c, account.getAccountNumber(), t);
                }
                c.commit();
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new DataAccessException("Could not update account " + account.getAccountNumber(), e);
        }
    }

    // ---------------- DELETE ----------------
    /** Deleting an account also deletes its transactions (ON DELETE CASCADE). */
    public void delete(String accountNumber) {
        try (Connection c = DatabaseManager.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM account WHERE account_number = ?")) {
            ps.setString(1, accountNumber);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Could not delete account " + accountNumber, e);
        }
    }
}
