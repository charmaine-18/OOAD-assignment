package bank.dao;

import java.util.ArrayList;
import java.util.List;

import bank.model.*;

/** Demo customers used to fill an empty database (and the in-memory context). */
public final class SampleData {
    private SampleData() { }

    public static List<Customer> customers() {
        List<Customer> list = new ArrayList<>();

        IndividualCustomer thabo = new IndividualCustomer(
                "C001", "Plot 123, Gaborone", "thabo", "pass123", "Thabo", "Molefe", true);
        SavingsAccount savings = new SavingsAccount("S1001", "Main Mall", 1000);
        InvestmentAccount invest = new InvestmentAccount("I2001", "Main Mall", 2000);
        ChequeAccount cheque = new ChequeAccount("CH3001", "Main Mall", 500,
                new Employer("Acme Ltd", "Gaborone"));
        savings.deposit(250);
        cheque.withdraw(75);
        thabo.addAccount(savings);
        thabo.addAccount(invest);
        thabo.addAccount(cheque);
        list.add(thabo);

        CompanyCustomer acme = new CompanyCustomer(
                "C002", "Fairgrounds, Gaborone", "acme", "acme123", "Acme Ltd", "BW00012345");
        acme.addAccount(new SavingsAccount("S1002", "Fairgrounds", 5000));
        acme.addAccount(new InvestmentAccount("I2002", "Fairgrounds", 10000));
        list.add(acme);

        return list;
    }
}
