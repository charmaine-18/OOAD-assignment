package bank.dao;

import bank.model.Customer;
import bank.model.Transaction;

public final class DatabaseSeeder {
    private DatabaseSeeder() { }

    /** Fills an empty database with sample data; otherwise just keeps transaction ids in sync. */
    public static void seedIfEmpty() {
        CustomerDAO customerDAO = new CustomerDAO();
        if (customerDAO.findAll().isEmpty()) {
            for (Customer c : SampleData.customers()) {
                customerDAO.insert(c);
            }
        } else {
            Transaction.syncNextId(new TransactionDAO().maxId());
        }
    }
}
