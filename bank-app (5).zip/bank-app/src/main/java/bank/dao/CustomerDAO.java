package bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import bank.model.*;

/** CRUD for customers. Loaded customers come with their accounts attached. */
public class CustomerDAO {
    private final AccountDAO accountDAO = new AccountDAO();

    // ---------------- CREATE ----------------
    /** Inserts the customer, then each of their accounts. */
    public void insert(Customer customer) {
        String sql = "INSERT INTO customer (customer_id, customer_type, address, username, password_hash, "
                + "first_name, surname, employed, company_name, registration_no) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = DatabaseManager.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, customer.getCustomerId());
            ps.setString(2, customer.getCustomerType());
            ps.setString(3, customer.getAddress());
            ps.setString(4, customer.getUsername());
            ps.setString(5, customer.getPasswordHash());
            if (customer instanceof IndividualCustomer ind) {
                ps.setString(6, ind.getFirstName());
                ps.setString(7, ind.getSurname());
                ps.setBoolean(8, ind.isEmployed());
                ps.setNull(9, Types.VARCHAR);
                ps.setNull(10, Types.VARCHAR);
            } else if (customer instanceof CompanyCustomer co) {
                ps.setNull(6, Types.VARCHAR);
                ps.setNull(7, Types.VARCHAR);
                ps.setNull(8, Types.BOOLEAN);
                ps.setString(9, co.getCompanyName());
                ps.setString(10, co.getRegistrationNo());
            }
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Could not insert customer " + customer.getCustomerId(), e);
        }
        for (Account account : customer.getAccounts()) {
            accountDAO.insert(customer.getCustomerId(), account);
        }
    }

    // ---------------- READ ----------------
    public Customer findByUsername(String username) {
        return findOne("SELECT * FROM customer WHERE LOWER(username) = LOWER(?)", username);
    }

    public Customer findById(String customerId) {
        return findOne("SELECT * FROM customer WHERE customer_id = ?", customerId);
    }

    public List<Customer> findAll() {
        List<Customer> customers = new ArrayList<>();
        try (Connection c = DatabaseManager.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM customer ORDER BY customer_id");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                customers.add(fromRow(rs));
            }
        } catch (SQLException e) {
            throw new DataAccessException("Could not load customers", e);
        }
        customers.forEach(this::attachAccounts);
        return customers;
    }

    private Customer findOne(String sql, String parameter) {
        Customer customer = null;
        try (Connection c = DatabaseManager.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, parameter);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    customer = fromRow(rs);
                }
            }
        } catch (SQLException e) {
            throw new DataAccessException("Could not load customer " + parameter, e);
        }
        if (customer != null) {
            attachAccounts(customer);
        }
        return customer;
    }

    private void attachAccounts(Customer customer) {
        for (Account account : accountDAO.findByCustomerId(customer.getCustomerId())) {
            customer.addAccount(account);
        }
    }

    private Customer fromRow(ResultSet rs) throws SQLException {
        String id = rs.getString("customer_id");
        String address = rs.getString("address");
        String username = rs.getString("username");
        Customer customer;
        if ("Individual".equals(rs.getString("customer_type"))) {
            customer = new IndividualCustomer(id, address, username, "", rs.getString("first_name"),
                    rs.getString("surname"), rs.getBoolean("employed"));
        } else {
            customer = new CompanyCustomer(id, address, username, "", rs.getString("company_name"),
                    rs.getString("registration_no"));
        }
        customer.setPasswordHash(rs.getString("password_hash"));   // restore the stored hash
        return customer;
    }

    /** Next free customer id, e.g. C003 (replaces a database sequence). */
    public String nextId() {
        int highest = 0;
        try (Connection c = DatabaseManager.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT customer_id FROM customer");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String id = rs.getString(1);
                if (id.matches("C\\d+")) {
                    highest = Math.max(highest, Integer.parseInt(id.substring(1)));
                }
            }
        } catch (SQLException e) {
            throw new DataAccessException("Could not generate a customer id", e);
        }
        return String.format("C%03d", highest + 1);
    }

    // ---------------- UPDATE ----------------
    public void update(Customer customer) {
        String sql = "UPDATE customer SET address = ?, password_hash = ? WHERE customer_id = ?";
        try (Connection c = DatabaseManager.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, customer.getAddress());
            ps.setString(2, customer.getPasswordHash());
            ps.setString(3, customer.getCustomerId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Could not update customer " + customer.getCustomerId(), e);
        }
    }

    // ---------------- DELETE ----------------
    /** Also removes the customer's accounts and transactions (ON DELETE CASCADE). */
    public void delete(String customerId) {
        try (Connection c = DatabaseManager.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM customer WHERE customer_id = ?")) {
            ps.setString(1, customerId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Could not delete customer " + customerId, e);
        }
    }
}
