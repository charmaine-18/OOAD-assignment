package bank;

import bank.dao.DatabaseManager;
import bank.dao.DatabaseSeeder;
import bank.controller.AccountController;
import bank.controller.AppContext;
import bank.controller.LoginController;
import bank.controller.OpenAccountController;
import bank.controller.RegisterController;
import bank.view.AccountView;
import bank.view.LoginView;
import bank.view.OpenAccountView;
import bank.view.RegisterView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    private Stage stage;
    private final AppContext context = new AppContext();

    @Override
    public void start(Stage primaryStage) {
        DatabaseManager.initialise();      // create tables if needed
        DatabaseSeeder.seedIfEmpty();      // demo data on first run
        this.stage = primaryStage;
        stage.setTitle("Banking System");
        showLogin();
        stage.show();
    }

    private void showLogin() {
        LoginView view = new LoginView();
        new LoginController(view, context, this::showAccounts, this::showRegister);
        stage.setScene(new Scene(view.getRoot(), 420, 380));
    }

    private void showAccounts() {
        AccountView view = new AccountView();
        new AccountController(view, context, this::showLogin, this::showOpenAccount);
        stage.setScene(new Scene(view.getRoot(), 760, 620));
    }

    private void showRegister() {
        RegisterView view = new RegisterView();
        new RegisterController(view, context, this::showLogin);
        stage.setScene(new Scene(view.getRoot(), 520, 600));
    }

    private void showOpenAccount() {
        OpenAccountView view = new OpenAccountView();
        new OpenAccountController(view, context, this::showAccounts);
        stage.setScene(new Scene(view.getRoot(), 520, 480));
    }

    public static void main(String[] args) {
        launch(args);
    }
}
