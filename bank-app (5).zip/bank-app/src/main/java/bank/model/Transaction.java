package bank.model;

import java.time.LocalDate;

public class Transaction {
    // Id generator for new transactions. After loading from the database it is synced past the highest stored id.
    private static int nextId = 1;

    private final int transactionId;
    private final LocalDate date;
    private final String type;          // e.g. DEPOSIT, WITHDRAWAL, INTEREST, OPENING
    private final double amount;
    private final double balanceAfter;

    /** Creates a brand-new transaction dated today. */
    public Transaction(String type, double amount, double balanceAfter) {
        this(nextId++, LocalDate.now(), type, amount, balanceAfter);
    }

    /** Restores an existing transaction (used when loading from the database). */
    public Transaction(int transactionId, LocalDate date, String type, double amount, double balanceAfter) {
        this.transactionId = transactionId;
        this.date = date;
        this.type = type;
        this.amount = amount;
        this.balanceAfter = balanceAfter;
    }

    /** Makes sure new ids never clash with ids already stored. */
    public static void syncNextId(int highestExistingId) {
        nextId = Math.max(nextId, highestExistingId + 1);
    }

    public int getTransactionId() { return transactionId; }
    public LocalDate getDate() { return date; }
    public String getType() { return type; }
    public double getAmount() { return amount; }
    public double getBalanceAfter() { return balanceAfter; }

    @Override
    public String toString() {
        return String.format("#%d %s %-10s %10.2f  balance: %.2f",
                transactionId, date, type, amount, balanceAfter);
    }
}
