package bank.model;

import java.time.LocalDate;
import java.util.List;

public class ChequeAccount extends Account implements Withdrawable {
    private final Employer employer;     // ChequeAccount 1 --> 1 Employer

    public ChequeAccount(String accountNumber, String branch, double openingBalance, Employer employer) {
        super(accountNumber, branch, openingBalance);
        if (employer == null) {
            throw new IllegalArgumentException("A cheque account requires employer details.");
        }
        this.employer = employer;
    }

    /** Restores an existing account from the database. */
    public ChequeAccount(String accountNumber, String branch, double balance, LocalDate openDate,
                         List<Transaction> transactions, Employer employer) {
        super(accountNumber, branch, balance, openDate, transactions);
        this.employer = employer;
    }

    public Employer getEmployer() { return employer; }

    @Override
    public void withdraw(double amount) {
        debit(amount);
    }

    @Override
    public String getAccountType() { return "Cheque"; }
}
