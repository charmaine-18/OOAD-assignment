package bank.model;

import java.time.LocalDate;
import java.util.List;

public class InvestmentAccount extends Account implements Withdrawable, InterestBearing {
    private static final double RATE = 0.05;                 // monthly rate
    public static final double MIN_OPENING = 500.00;         // BWP 500 minimum (use case: Verify BWP 500)

    public InvestmentAccount(String accountNumber, String branch, double openingBalance) {
        super(accountNumber, branch, validateOpening(openingBalance));
    }

    /** Restores an existing account from the database (the opening minimum is not re-checked). */
    public InvestmentAccount(String accountNumber, String branch, double balance, LocalDate openDate,
                             List<Transaction> transactions) {
        super(accountNumber, branch, balance, openDate, transactions);
    }

    private static double validateOpening(double openingBalance) {
        if (openingBalance < MIN_OPENING) {
            throw new IllegalArgumentException(
                    String.format("An investment account needs at least BWP %.2f to open.", MIN_OPENING));
        }
        return openingBalance;
    }

    @Override
    public void withdraw(double amount) {
        debit(amount);
    }

    @Override
    public double calculateInterest() {
        return getBalance() * RATE;
    }

    @Override
    public void payInterest() {
        double interest = calculateInterest();
        if (interest > 0) {
            deposit(interest, "INTEREST");
        }
    }

    @Override
    public String getAccountType() { return "Investment"; }
}
