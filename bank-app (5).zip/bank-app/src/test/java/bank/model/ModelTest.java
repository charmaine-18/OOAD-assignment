package bank.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/** Unit tests for the core business rules (no GUI, no database). */
class ModelTest {
    private static final double DELTA = 0.001;

    @Test
    void depositIncreasesBalanceAndRecordsTransaction() {
        SavingsAccount a = new SavingsAccount("S1", "Main", 100);
        a.deposit(50);
        assertEquals(150.0, a.getBalance(), DELTA);
        assertEquals(2, a.getTransactions().size());
        Transaction last = a.getTransactions().get(1);
        assertEquals("DEPOSIT", last.getType());
        assertEquals(150.0, last.getBalanceAfter(), DELTA);
    }

    @Test
    void depositOfZeroOrNegativeIsRejected() {
        SavingsAccount a = new SavingsAccount("S1", "Main", 100);
        assertThrows(IllegalArgumentException.class, () -> a.deposit(0));
        assertThrows(IllegalArgumentException.class, () -> a.deposit(-10));
        assertEquals(100.0, a.getBalance(), DELTA);
    }

    @Test
    void nonFiniteAmountsAreRejected() {
        SavingsAccount a = new SavingsAccount("S1", "Main", 100);
        assertThrows(IllegalArgumentException.class, () -> a.deposit(Double.NaN));
        assertThrows(IllegalArgumentException.class, () -> a.deposit(Double.POSITIVE_INFINITY));
        assertEquals(100.0, a.getBalance(), DELTA);
    }

    @Test
    void withdrawalReducesBalance() {
        ChequeAccount a = new ChequeAccount("C1", "Main", 500, new Employer("Acme", "Gaborone"));
        a.withdraw(120);
        assertEquals(380.0, a.getBalance(), DELTA);
        assertEquals("WITHDRAWAL", a.getTransactions().get(a.getTransactions().size() - 1).getType());
    }

    @Test
    void withdrawalBeyondBalanceIsRejectedAndBalanceUnchanged() {
        ChequeAccount a = new ChequeAccount("C1", "Main", 500, new Employer("Acme", "Gaborone"));
        assertThrows(InsufficientFundsException.class, () -> a.withdraw(500.01));
        assertEquals(500.0, a.getBalance(), DELTA);
        assertEquals(1, a.getTransactions().size());   // only the OPENING transaction
    }

    @Test
    void investmentAccountEnforcesMinimumOpeningBalance() {
        assertThrows(IllegalArgumentException.class, () -> new InvestmentAccount("I1", "Main", 499.99));
        assertEquals(500.0, new InvestmentAccount("I2", "Main", 500).getBalance(), DELTA);
    }

    @Test
    void chequeAccountRequiresEmployer() {
        assertThrows(IllegalArgumentException.class, () -> new ChequeAccount("C1", "Main", 0, null));
    }

    @Test
    void savingsInterestIsCalculatedAndPaid() {
        SavingsAccount a = new SavingsAccount("S1", "Main", 1000);
        assertEquals(0.5, a.calculateInterest(), DELTA);
        a.payInterest();
        assertEquals(1000.5, a.getBalance(), DELTA);
        assertEquals("INTEREST", a.getTransactions().get(a.getTransactions().size() - 1).getType());
    }

    @Test
    void investmentInterestIsCalculatedAndPaid() {
        InvestmentAccount a = new InvestmentAccount("I1", "Main", 1000);
        assertEquals(50.0, a.calculateInterest(), DELTA);
        a.payInterest();
        assertEquals(1050.0, a.getBalance(), DELTA);
    }

    @Test
    void savingsAccountsCannotBeWithdrawnFrom() {
        assertFalse(new SavingsAccount("S1", "Main", 100) instanceof Withdrawable);
    }

    @Test
    void customerLoginChecksHashedPassword() {
        IndividualCustomer c = new IndividualCustomer("C1", "addr", "thabo", "pass123", "Thabo", "Molefe", true);
        assertTrue(c.login("pass123"));
        assertFalse(c.login("wrong"));
        assertFalse(c.login(null));
        assertNotEquals("pass123", c.getPasswordHash());
        assertEquals(64, c.getPasswordHash().length());   // SHA-256 in hex
    }

    @Test
    void customerTypesAreReported() {
        assertEquals("Individual", new IndividualCustomer("C1", "a", "u1", "p", "A", "B", false).getCustomerType());
        assertEquals("Company", new CompanyCustomer("C2", "a", "u2", "p", "Acme", "BW1").getCustomerType());
    }
}
