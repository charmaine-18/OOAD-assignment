package bank;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javafx.application.Platform;

/** Helpers to run test steps on the JavaFX thread. */
final class FxTestSupport {
    private FxTestSupport() { }

    interface FxAction { void run() throws Exception; }

    /** Starts the JavaFX toolkit once. Returns false if no display is available. */
    static boolean startToolkit() {
        try {
            Platform.startup(() -> { });
            return true;
        } catch (IllegalStateException alreadyRunning) {
            return true;
        } catch (Throwable noDisplay) {
            return false;
        }
    }

    static void onFx(FxAction action) throws Exception {
        if (Platform.isFxApplicationThread()) {
            action.run();
            return;
        }
        CompletableFuture<Void> done = new CompletableFuture<>();
        Platform.runLater(() -> {
            try {
                action.run();
                done.complete(null);
            } catch (Throwable t) {
                done.completeExceptionally(t);
            }
        });
        try {
            done.get(15, TimeUnit.SECONDS);
        } catch (ExecutionException e) {
            if (e.getCause() instanceof Exception ex) throw ex;
            if (e.getCause() instanceof Error err) throw err;
            throw e;
        }
    }
}
