package bank;

import static bank.FxTestSupport.onFx;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import bank.controller.AccountController;
import bank.controller.AppContext;
import bank.controller.LoginController;
import bank.controller.OpenAccountController;
import bank.controller.RegisterController;
import bank.dao.AccountDAO;
import bank.dao.DatabaseManager;
import bank.dao.CustomerDAO;
import bank.dao.DatabaseSeeder;
import bank.model.Account;
import bank.model.ChequeAccount;
import bank.model.CompanyCustomer;
import bank.model.Customer;
import bank.model.IndividualCustomer;
import bank.model.SavingsAccount;
import bank.model.Transaction;
import bank.view.AccountView;
import bank.view.LoginView;
import bank.view.OpenAccountView;
import bank.view.RegisterView;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

/**
 * Integration tests: real JavaFX views + real controllers + real model + real JDBC/H2.
 * Each test drives the GUI the way a user would (type, click) and then checks both the
 * screen and the database.
 */
class IntegrationTest {
    private static final double DELTA = 0.001;

    private AppContext context;
    private LoginView loginView;
    private AccountView accountView;
    private boolean loginSucceeded;
    private boolean loggedOut;

    @BeforeAll
    static void startFx() {
        assumeTrue(FxTestSupport.startToolkit(),
                "JavaFX toolkit could not start (no display). Run inside the Codespaces desktop.");
    }

    @BeforeEach
    void freshDatabase() {
        DatabaseManager.setUrl("jdbc:h2:mem:integration;DB_CLOSE_DELAY=-1");
        DatabaseManager.resetDatabase();
        DatabaseSeeder.seedIfEmpty();
        context = new AppContext();
        loginSucceeded = false;
        loggedOut = false;
    }

    // ===================== helpers =====================
    @SuppressWarnings("unchecked")
    private static <T extends Node> T find(Parent root, String id) {
        Node node = root.lookup(id);
        assertNotNull(node, "UI element not found: " + id);
        return (T) node;
    }

    private void typeCredentialsAndLogin(String user, String password) throws Exception {
        onFx(() -> {
            loginView = new LoginView();
            new LoginController(loginView, context, () -> loginSucceeded = true);
            ((TextField) find(loginView.getRoot(), "#usernameField")).setText(user);
            ((TextField) find(loginView.getRoot(), "#passwordField")).setText(password);
            ((Button) find(loginView.getRoot(), "#loginButton")).fire();
        });
    }

    private void showAccountScreen() throws Exception {
        onFx(() -> {
            accountView = new AccountView();
            new AccountController(accountView, context, () -> loggedOut = true);
        });
    }

    private void loginAndOpenAccounts(String user, String password) throws Exception {
        typeCredentialsAndLogin(user, password);
        assertTrue(loginSucceeded, "login should have succeeded");
        showAccountScreen();
    }

    private void selectAccount(String accountNumber) throws Exception {
        onFx(() -> {
            ComboBox<String> combo = find(accountView.getRoot(), "#accountCombo");
            for (int i = 0; i < combo.getItems().size(); i++) {
                if (combo.getItems().get(i).startsWith(accountNumber)) {
                    combo.getSelectionModel().select(i);
                    combo.getOnAction().handle(new ActionEvent());
                    return;
                }
            }
            fail("Account not in dropdown: " + accountNumber);
        });
    }

    private void enterAmountAndClick(String amount, String buttonId) throws Exception {
        onFx(() -> {
            ((TextField) find(accountView.getRoot(), "#amountField")).setText(amount);
            ((Button) find(accountView.getRoot(), buttonId)).fire();
        });
    }

    private String label(Parent root, String id) {
        return ((Label) find(root, id)).getText();
    }

    private int historyRows() {
        TableView<?> table = find(accountView.getRoot(), "#historyTable");
        return table.getItems().size();
    }

    private Account dbAccount(String number) {
        return new AccountDAO().findByNumber(number);   // fresh read straight from the database
    }

    // ===================== IT-01 .. IT-04 : login =====================
    @Test
    void IT01_validLoginReachesAccountScreen() throws Exception {
        typeCredentialsAndLogin("thabo", "pass123");
        assertTrue(loginSucceeded);
        assertNotNull(context.getCurrentCustomer());
        assertEquals("thabo", context.getCurrentCustomer().getUsername());
    }

    @Test
    void IT02_wrongPasswordIsRejected() throws Exception {
        typeCredentialsAndLogin("thabo", "wrong");
        assertFalse(loginSucceeded);
        assertNull(context.getCurrentCustomer());
        assertEquals("Invalid username or password.", label(loginView.getRoot(), "#messageLabel"));
    }

    @Test
    void IT03_emptyFieldsAreRejectedByTheController() throws Exception {
        typeCredentialsAndLogin("", "");
        assertFalse(loginSucceeded);
        assertEquals("Please enter both username and password.", label(loginView.getRoot(), "#messageLabel"));
    }

    @Test
    void IT04_unknownUserIsRejected() throws Exception {
        typeCredentialsAndLogin("nobody", "pass123");
        assertFalse(loginSucceeded);
        assertEquals("Invalid username or password.", label(loginView.getRoot(), "#messageLabel"));
    }

    // ===================== IT-05 : account screen content =====================
    @Test
    void IT05_accountScreenShowsCustomerAccountsBalanceAndHistory() throws Exception {
        loginAndOpenAccounts("thabo", "pass123");
        assertEquals("Welcome, Thabo Molefe", label(accountView.getRoot(), "#welcomeLabel"));
        ComboBox<String> combo = find(accountView.getRoot(), "#accountCombo");
        assertEquals(3, combo.getItems().size());

        selectAccount("S1001");
        assertEquals("BWP 1250.00", label(accountView.getRoot(), "#balanceLabel"));
        assertEquals(2, historyRows());   // OPENING + DEPOSIT from the sample data
    }

    // ===================== IT-06 : full deposit flow =====================
    @Test
    void IT06_depositFlowGuiToControllerToModelToDatabase() throws Exception {
        loginAndOpenAccounts("thabo", "pass123");
        selectAccount("S1001");
        enterAmountAndClick("100", "#depositButton");

        // screen
        assertEquals("BWP 1350.00", label(accountView.getRoot(), "#balanceLabel"));
        assertEquals("Deposited BWP 100.00 successfully.", label(accountView.getRoot(), "#messageLabel"));
        assertEquals(3, historyRows());

        // database (read independently of the objects the controller holds)
        Account saved = dbAccount("S1001");
        assertEquals(1350.0, saved.getBalance(), DELTA);
        List<Transaction> tx = saved.getTransactions();
        assertEquals(3, tx.size());
        Transaction last = tx.get(tx.size() - 1);
        assertEquals("DEPOSIT", last.getType());
        assertEquals(100.0, last.getAmount(), DELTA);
        assertEquals(1350.0, last.getBalanceAfter(), DELTA);
    }

    // ===================== IT-07 : full withdrawal flow =====================
    @Test
    void IT07_withdrawalFlowGuiToControllerToModelToDatabase() throws Exception {
        loginAndOpenAccounts("thabo", "pass123");
        selectAccount("CH3001");
        enterAmountAndClick("25", "#withdrawButton");

        assertEquals("BWP 400.00", label(accountView.getRoot(), "#balanceLabel"));
        Account saved = dbAccount("CH3001");
        assertEquals(400.0, saved.getBalance(), DELTA);
        Transaction last = saved.getTransactions().get(saved.getTransactions().size() - 1);
        assertEquals("WITHDRAWAL", last.getType());
        assertEquals(25.0, last.getAmount(), DELTA);
    }

    // ===================== IT-08 : rejected withdrawal =====================
    @Test
    void IT08_withdrawalBeyondBalanceIsRejectedAndDatabaseUnchanged() throws Exception {
        loginAndOpenAccounts("thabo", "pass123");
        selectAccount("CH3001");
        enterAmountAndClick("10000", "#withdrawButton");

        assertTrue(label(accountView.getRoot(), "#messageLabel").startsWith("Insufficient funds"));
        assertEquals("BWP 425.00", label(accountView.getRoot(), "#balanceLabel"));
        Account saved = dbAccount("CH3001");
        assertEquals(425.0, saved.getBalance(), DELTA);
        assertEquals(2, saved.getTransactions().size());
    }

    // ===================== IT-09 : invalid amounts =====================
    @Test
    void IT09_invalidAmountsAreRejectedAndDatabaseUnchanged() throws Exception {
        loginAndOpenAccounts("thabo", "pass123");
        selectAccount("S1001");

        enterAmountAndClick("abc", "#depositButton");
        assertEquals("Amount must be a number, e.g. 150.00", label(accountView.getRoot(), "#messageLabel"));

        enterAmountAndClick("", "#depositButton");
        assertEquals("Please enter an amount.", label(accountView.getRoot(), "#messageLabel"));

        enterAmountAndClick("0", "#depositButton");
        assertEquals("Deposit amount must be greater than zero.", label(accountView.getRoot(), "#messageLabel"));

        enterAmountAndClick("-5", "#depositButton");
        assertEquals("Deposit amount must be greater than zero.", label(accountView.getRoot(), "#messageLabel"));

        Account saved = dbAccount("S1001");
        assertEquals(1250.0, saved.getBalance(), DELTA);
        assertEquals(2, saved.getTransactions().size());
    }

    // ===================== IT-10 : savings cannot withdraw =====================
    @Test
    void IT10_withdrawButtonIsDisabledForSavingsAccounts() throws Exception {
        loginAndOpenAccounts("thabo", "pass123");
        selectAccount("S1001");
        assertTrue(((Button) find(accountView.getRoot(), "#withdrawButton")).isDisabled());
        selectAccount("CH3001");
        assertFalse(((Button) find(accountView.getRoot(), "#withdrawButton")).isDisabled());
    }

    // ===================== IT-11 : persistence across sessions =====================
    @Test
    void IT11_dataSurvivesLogoutAndANewSession() throws Exception {
        loginAndOpenAccounts("thabo", "pass123");
        selectAccount("S1001");
        enterAmountAndClick("200", "#depositButton");

        // brand-new application context = brand-new session; the only shared state is the database
        context = new AppContext();
        loginSucceeded = false;
        loginAndOpenAccounts("thabo", "pass123");
        selectAccount("S1001");
        assertEquals("BWP 1450.00", label(accountView.getRoot(), "#balanceLabel"));
        assertEquals(3, historyRows());
    }

    // ===================== IT-12 : logout =====================
    @Test
    void IT12_logoutClearsTheSession() throws Exception {
        loginAndOpenAccounts("thabo", "pass123");
        onFx(() -> ((Button) find(accountView.getRoot(), "#logoutButton")).fire());
        assertTrue(loggedOut);
        assertNull(context.getCurrentCustomer());
    }

    // ===================== IT-13 : company customer =====================
    @Test
    void IT13_companyCustomerSeesTheirOwnAccountsOnly() throws Exception {
        loginAndOpenAccounts("acme", "acme123");
        assertEquals("Welcome, Acme Ltd", label(accountView.getRoot(), "#welcomeLabel"));
        ComboBox<String> combo = find(accountView.getRoot(), "#accountCombo");
        assertEquals(2, combo.getItems().size());
        assertTrue(combo.getItems().stream().noneMatch(s -> s.startsWith("S1001")));
    }

    // ============================================================
    //  Registration and open-account screens
    // ============================================================
    private RegisterView registerView;
    private OpenAccountView openAccountView;
    private boolean backClicked;

    private void showRegister() throws Exception {
        onFx(() -> {
            registerView = new RegisterView();
            new RegisterController(registerView, context, () -> backClicked = true);
        });
    }

    private void register(String type, String user, String pw, String confirm, String address,
                          String first, String surname, String company, String regNo) throws Exception {
        onFx(() -> {
            Parent r = registerView.getRoot();
            ComboBox<String> typeCombo = find(r, "#typeCombo");
            typeCombo.setValue(type);
            typeCombo.getOnAction().handle(new ActionEvent());
            ((TextField) find(r, "#usernameField")).setText(user);
            ((TextField) find(r, "#passwordField")).setText(pw);
            ((TextField) find(r, "#confirmField")).setText(confirm);
            ((TextField) find(r, "#addressField")).setText(address);
            ((TextField) find(r, "#firstNameField")).setText(first);
            ((TextField) find(r, "#surnameField")).setText(surname);
            ((TextField) find(r, "#companyNameField")).setText(company);
            ((TextField) find(r, "#registrationNoField")).setText(regNo);
            ((Button) find(r, "#registerButton")).fire();
        });
    }

    private void showOpenAccount() throws Exception {
        onFx(() -> {
            openAccountView = new OpenAccountView();
            new OpenAccountController(openAccountView, context, () -> backClicked = true);
        });
    }

    private void chooseAccountType(String type) throws Exception {
        onFx(() -> {
            ComboBox<String> combo = find(openAccountView.getRoot(), "#typeCombo");
            combo.setValue(type);
            combo.getOnAction().handle(new ActionEvent());
        });
    }

    private void openAccount(String type, String branch, String amount, String employer, String employerAddress)
            throws Exception {
        chooseAccountType(type);
        onFx(() -> {
            Parent r = openAccountView.getRoot();
            ((TextField) find(r, "#branchField")).setText(branch);
            ((TextField) find(r, "#amountField")).setText(amount);
            ((TextField) find(r, "#employerNameField")).setText(employer);
            ((TextField) find(r, "#employerAddressField")).setText(employerAddress);
            ((Button) find(r, "#openButton")).fire();
        });
    }

    private String registerMessage() { return label(registerView.getRoot(), "#messageLabel"); }
    private String openMessage() { return label(openAccountView.getRoot(), "#messageLabel"); }

    // ===================== IT-14 : register individual, then log in =====================
    @Test
    void IT14_registeredIndividualIsSavedAndCanLogIn() throws Exception {
        showRegister();
        register("Individual", "neo", "secret1", "secret1", "Block 8, Maun", "Neo", "Seleka", "", "");
        assertTrue(registerMessage().startsWith("Registration successful"));

        Customer saved = new CustomerDAO().findByUsername("neo");
        assertNotNull(saved);
        assertTrue(saved instanceof IndividualCustomer);
        assertEquals("C003", saved.getCustomerId());
        assertEquals(0, saved.getAccounts().size());

        typeCredentialsAndLogin("neo", "secret1");
        assertTrue(loginSucceeded);
    }

    // ===================== IT-15 : register company =====================
    @Test
    void IT15_registeredCompanyIsSavedWithItsDetails() throws Exception {
        showRegister();
        register("Company", "brick", "secret1", "secret1", "Plot 9, Francistown", "", "", "Brick Co", "BW123");
        assertTrue(registerMessage().startsWith("Registration successful"));

        Customer saved = new CustomerDAO().findByUsername("brick");
        assertTrue(saved instanceof CompanyCustomer);
        assertEquals("BW123", ((CompanyCustomer) saved).getRegistrationNo());
    }

    // ===================== IT-16 : duplicate username =====================
    @Test
    void IT16_duplicateUsernameIsRejected() throws Exception {
        showRegister();
        register("Individual", "thabo", "secret1", "secret1", "Somewhere", "Tom", "Smith", "", "");
        assertEquals("That username is already taken.", registerMessage());
        assertEquals(2, new CustomerDAO().findAll().size());
    }

    // ===================== IT-17 : registration validation =====================
    @Test
    void IT17_invalidRegistrationInputIsRejectedAndNothingIsSaved() throws Exception {
        showRegister();
        register("Individual", "neo", "secret1", "different", "Block 8", "Neo", "Seleka", "", "");
        assertEquals("Passwords do not match.", registerMessage());

        register("Individual", "neo", "123", "123", "Block 8", "Neo", "Seleka", "", "");
        assertEquals("Password must be at least 6 characters.", registerMessage());

        register("Individual", "", "secret1", "secret1", "Block 8", "Neo", "Seleka", "", "");
        assertEquals("Please fill in all required fields.", registerMessage());

        register("Company", "brick", "secret1", "secret1", "Plot 9", "", "", "", "");
        assertEquals("Please fill in all required fields.", registerMessage());

        register("Individual", "a b", "secret1", "secret1", "Block 8", "Neo", "Seleka", "", "");
        assertEquals("Username must be at least 3 characters with no spaces.", registerMessage());

        assertEquals(2, new CustomerDAO().findAll().size());
    }

    // ===================== IT-18 : customer with no accounts =====================
    @Test
    void IT18_newCustomerWithoutAccountsIsToldToOpenOne() throws Exception {
        showRegister();
        register("Individual", "neo", "secret1", "secret1", "Block 8", "Neo", "Seleka", "", "");
        loginAndOpenAccounts("neo", "secret1");

        ComboBox<String> combo = find(accountView.getRoot(), "#accountCombo");
        assertEquals(0, combo.getItems().size());
        assertTrue(label(accountView.getRoot(), "#messageLabel").startsWith("You have no accounts yet"));

        enterAmountAndClick("50", "#depositButton");
        assertEquals("Please open an account first.", label(accountView.getRoot(), "#messageLabel"));
    }

    // ===================== IT-19 : open savings account, full flow =====================
    @Test
    void IT19_openSavingsAccountIsSavedAndShownOnTheAccountScreen() throws Exception {
        typeCredentialsAndLogin("thabo", "pass123");
        assertTrue(loginSucceeded);
        showOpenAccount();
        openAccount("Savings", "Main Mall", "300", "", "");

        assertEquals("Account S1003 opened successfully with BWP 300.00.", openMessage());
        Account saved = dbAccount("S1003");
        assertTrue(saved instanceof SavingsAccount);
        assertEquals(300.0, saved.getBalance(), DELTA);
        assertEquals(1, saved.getTransactions().size());
        assertEquals(4, context.getCurrentCustomer().getAccounts().size());

        showAccountScreen();
        ComboBox<String> combo = find(accountView.getRoot(), "#accountCombo");
        assertEquals(4, combo.getItems().size());
    }

    // ===================== IT-20 : investment minimum =====================
    @Test
    void IT20_investmentBelowMinimumIsRejectedAndNothingIsSaved() throws Exception {
        typeCredentialsAndLogin("thabo", "pass123");
        showOpenAccount();
        openAccount("Investment", "Main Mall", "100", "", "");

        assertEquals("An investment account needs at least BWP 500.00 to open.", openMessage());
        assertNull(dbAccount("I2003"));
        assertEquals(3, context.getCurrentCustomer().getAccounts().size());

        openAccount("Investment", "Main Mall", "500", "", "");
        assertTrue(openMessage().startsWith("Account I2003 opened successfully"));
        assertEquals(500.0, dbAccount("I2003").getBalance(), DELTA);
    }

    // ===================== IT-21 : cheque account needs employer =====================
    @Test
    void IT21_chequeAccountNeedsEmployerDetails() throws Exception {
        typeCredentialsAndLogin("thabo", "pass123");
        showOpenAccount();
        openAccount("Cheque", "Main Mall", "50", "", "");
        assertEquals("Employer name is required for a cheque account.", openMessage());
        assertNull(dbAccount("CH3002"));

        openAccount("Cheque", "Main Mall", "50", "Widgets Ltd", "Lobatse");
        assertTrue(openMessage().startsWith("Account CH3002 opened successfully"));
        Account saved = dbAccount("CH3002");
        assertTrue(saved instanceof ChequeAccount);
        assertEquals("Widgets Ltd", ((ChequeAccount) saved).getEmployer().getCompanyName());
    }

    // ===================== IT-22 : invalid opening amounts =====================
    @Test
    void IT22_invalidOpeningAmountsAreRejected() throws Exception {
        typeCredentialsAndLogin("thabo", "pass123");
        showOpenAccount();

        openAccount("Savings", "Main Mall", "abc", "", "");
        assertEquals("Amount must be a number, e.g. 150.00", openMessage());

        openAccount("Savings", "Main Mall", "NaN", "", "");
        assertEquals("Amount must be a number, e.g. 150.00", openMessage());

        openAccount("Savings", "Main Mall", "-20", "", "");
        assertEquals("Opening balance cannot be negative.", openMessage());

        openAccount("Savings", "", "100", "", "");
        assertEquals("Please enter the branch.", openMessage());

        assertNull(dbAccount("S1003"));
    }

    // ===================== IT-23 : form adapts to account type =====================
    @Test
    void IT23_openAccountFormShowsHintsAndEmployerFieldsForTheChosenType() throws Exception {
        typeCredentialsAndLogin("thabo", "pass123");
        showOpenAccount();
        Parent r = openAccountView.getRoot();

        assertFalse(((TextField) find(r, "#employerNameField")).isVisible());

        chooseAccountType("Investment");
        assertEquals("Minimum opening deposit: BWP 500.00", label(r, "#hintLabel"));
        assertFalse(((TextField) find(r, "#employerNameField")).isVisible());

        chooseAccountType("Cheque");
        assertTrue(((TextField) find(r, "#employerNameField")).isVisible());
    }
}
