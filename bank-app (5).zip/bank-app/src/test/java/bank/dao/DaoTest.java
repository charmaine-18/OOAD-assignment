package bank.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import bank.model.*;

/** Tests the JDBC layer against an in-memory H2 database. */
class DaoTest {
    private final CustomerDAO customerDAO = new CustomerDAO();
    private final AccountDAO accountDAO = new AccountDAO();
    private static final double DELTA = 0.001;

    @BeforeEach
    void freshDatabase() {
        DatabaseManager.setUrl("jdbc:h2:mem:daotest;DB_CLOSE_DELAY=-1");
        DatabaseManager.resetDatabase();
        DatabaseSeeder.seedIfEmpty();
    }

    @Test
    void seededCustomerCanBeFoundAndLogsIn() {
        Customer c = customerDAO.findByUsername("thabo");
        assertNotNull(c);
        assertEquals("Individual", c.getCustomerType());
        assertTrue(c.login("pass123"));
        assertEquals(3, c.getAccounts().size());
        assertNotNull(customerDAO.findByUsername("THABO"));   // case-insensitive
    }

    @Test
    void unknownUsernameReturnsNull() {
        assertNull(customerDAO.findByUsername("nobody"));
    }

    @Test
    void accountTypesAndEmployerAreRestored() {
        Account cheque = accountDAO.findByNumber("CH3001");
        assertTrue(cheque instanceof ChequeAccount);
        assertEquals("Acme Ltd", ((ChequeAccount) cheque).getEmployer().getCompanyName());
        assertEquals(425.0, cheque.getBalance(), DELTA);
        assertTrue(accountDAO.findByNumber("S1001") instanceof SavingsAccount);
        assertTrue(accountDAO.findByNumber("I2001") instanceof InvestmentAccount);
    }

    @Test
    void companyCustomerIsRestored() {
        Customer c = customerDAO.findById("C002");
        assertTrue(c instanceof CompanyCustomer);
        assertEquals("BW00012345", ((CompanyCustomer) c).getRegistrationNo());
        assertEquals(2, c.getAccounts().size());
    }

    @Test
    void updatePersistsBalanceAndNewTransaction() {
        Account a = accountDAO.findByNumber("S1001");
        int before = a.getTransactions().size();
        a.deposit(100);
        accountDAO.update(a);

        Account reloaded = accountDAO.findByNumber("S1001");
        assertEquals(1350.0, reloaded.getBalance(), DELTA);
        assertEquals(before + 1, reloaded.getTransactions().size());
    }

    @Test
    void savingTwiceDoesNotDuplicateTransactions() {
        Account a = accountDAO.findByNumber("S1001");
        a.deposit(10);
        accountDAO.update(a);
        accountDAO.update(a);
        assertEquals(3, accountDAO.findByNumber("S1001").getTransactions().size());
    }

    @Test
    void insertNewCustomerWithAccounts() {
        IndividualCustomer c = new IndividualCustomer("C100", "Block 8", "neo", "secret", "Neo", "Seleka", false);
        c.addAccount(new SavingsAccount("S9000", "Francistown", 300));
        customerDAO.insert(c);

        Customer loaded = customerDAO.findById("C100");
        assertNotNull(loaded);
        assertTrue(loaded.login("secret"));
        assertEquals(1, loaded.getAccounts().size());
        assertEquals(300.0, loaded.getAccounts().get(0).getBalance(), DELTA);
    }

    @Test
    void duplicateUsernameIsRejected() {
        IndividualCustomer dup = new IndividualCustomer("C101", "x", "thabo", "p", "A", "B", false);
        assertThrows(DataAccessException.class, () -> customerDAO.insert(dup));
    }

    @Test
    void updateCustomerChangesAddress() {
        Customer c = customerDAO.findByUsername("thabo");
        c.setAddress("New address, Maun");
        customerDAO.update(c);
        assertEquals("New address, Maun", customerDAO.findByUsername("thabo").getAddress());
    }

    @Test
    void deletingAnAccountRemovesItAndItsTransactions() {
        accountDAO.delete("S1001");
        assertNull(accountDAO.findByNumber("S1001"));
        assertTrue(new TransactionDAO().findByAccount("S1001").isEmpty());
    }

    @Test
    void deletingACustomerCascadesToAccounts() {
        customerDAO.delete("C002");
        assertNull(customerDAO.findById("C002"));
        assertNull(accountDAO.findByNumber("S1002"));
        List<Customer> remaining = customerDAO.findAll();
        assertEquals(1, remaining.size());
    }

    @Test
    void nextCustomerIdFollowsExistingIds() {
        assertEquals("C003", customerDAO.nextId());
    }

    @Test
    void nextAccountNumbersFollowExistingNumbers() {
        assertEquals("S1003", accountDAO.nextAccountNumber("Savings"));
        assertEquals("I2003", accountDAO.nextAccountNumber("Investment"));
        assertEquals("CH3002", accountDAO.nextAccountNumber("Cheque"));
        assertThrows(IllegalArgumentException.class, () -> accountDAO.nextAccountNumber("Gold"));
    }
}
