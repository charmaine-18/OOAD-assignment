# Final Presentation – Demo Script and Talking Points (about 8 minutes)

## 1. Introduction (1 min)
- Banking system in Java: customers (individual / company) with Savings, Investment and Cheque accounts.
- Built in layers: **View -> Controller -> Model -> DAO -> H2 database**.
- Worked in GitHub Codespaces; every week is a Git commit.

## 2. Design (2 min) – show your Part A diagrams
- Use cases: login, deposit, withdraw, open account, view balance/history, pay interest.
- Class diagram: abstract `Customer` / `Account`; interfaces `Depositable`, `Withdrawable`, `InterestBearing`.
  Savings cannot withdraw; Investment needs BWP 500 minimum; Cheque needs an Employer.
- Sequence diagrams: Login and Deposit Funds. Explain that the code follows them exactly
  (`LoginView -> LoginController -> CustomerDAO -> Customer.login`).

## 3. Live demo (3 min)
1. Run `mvn javafx:run` and open the desktop on port 6080.
2. Click "New customer? Register here", register a new customer, go back and log in with it (it has no accounts yet).
   Click "Open new account" and open a Savings account. Then log out and login as `thabo / pass123`.
3. Select the Savings account, deposit 100 -> balance and history update.
4. Select the Cheque account, withdraw 10000 -> rejected (insufficient funds).
5. Select Savings -> Withdraw button is disabled (business rule).
6. Logout, login again -> the deposit is still there (it came from the database).

## 4. Code walkthrough (1.5 min)
- Model has no GUI or SQL code. Views have no business logic. Controllers connect them.
- DAOs use `PreparedStatement`, commit/rollback, and a schema matching the class diagram.

## 5. Testing (1 min)
- `mvn test`: 12 unit tests, 13 DAO tests, 23 GUI-to-database integration tests.
- Show the test report.

## Likely questions
- *Why separate controllers?* Views stay replaceable and the model testable.
- *Why hash passwords?* Plain text must never be stored.
- *What would you improve?* BigDecimal for money, open-account screen, teller interest run, account status (state diagram).
