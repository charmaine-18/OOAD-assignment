package bank.model;

public class SavingsAccount extends Account implements InterestBearing {
    private static final double RATE = 0.0005;   // monthly rate

    public SavingsAccount(String accountNumber, String branch, double openingBalance) {
        super(accountNumber, branch, openingBalance);
    }

    @Override
    public double calculateInterest() {
        return getBalance() * RATE;
    }

    @Override
    public void payInterest() {
        double interest = calculateInterest();
        if (interest > 0) {
            deposit(interest, "INTEREST");
        }
    }

    @Override
    public String getAccountType() { return "Savings"; }
}
