package bank.model;

/** Thrown when a withdrawal is rejected (use case: "Reject withdrawal"). */
public class InsufficientFundsException extends RuntimeException {
    public InsufficientFundsException(String message) {
        super(message);
    }
}
