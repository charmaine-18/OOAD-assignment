package bank.model;

/** Implemented by any account that accepts deposits. */
public interface Depositable {
    void deposit(double amount);
}
