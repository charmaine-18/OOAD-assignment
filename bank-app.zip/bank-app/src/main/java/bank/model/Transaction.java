package bank.model;

import java.time.LocalDate;

public class Transaction {
    // Temporary id generator; the database will take over this role in Week 7.
    private static int nextId = 1;

    private final int transactionId;
    private final LocalDate date;
    private final String type;          // e.g. DEPOSIT, WITHDRAWAL, INTEREST, OPENING
    private final double amount;
    private final double balanceAfter;

    public Transaction(String type, double amount, double balanceAfter) {
        this.transactionId = nextId++;
        this.date = LocalDate.now();
        this.type = type;
        this.amount = amount;
        this.balanceAfter = balanceAfter;
    }

    public int getTransactionId() { return transactionId; }
    public LocalDate getDate() { return date; }
    public String getType() { return type; }
    public double getAmount() { return amount; }
    public double getBalanceAfter() { return balanceAfter; }

    @Override
    public String toString() {
        return String.format("#%d %s %-10s %10.2f  balance: %.2f",
                transactionId, date, type, amount, balanceAfter);
    }
}
