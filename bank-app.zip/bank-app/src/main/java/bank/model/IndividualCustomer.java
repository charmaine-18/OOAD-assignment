package bank.model;

public class IndividualCustomer extends Customer {
    private String firstName;
    private String surname;
    private boolean employed;

    public IndividualCustomer(String customerId, String address, String username, String plainPassword,
                              String firstName, String surname, boolean employed) {
        super(customerId, address, username, plainPassword);
        this.firstName = firstName;
        this.surname = surname;
        this.employed = employed;
    }

    public String getFirstName() { return firstName; }
    public String getSurname() { return surname; }
    public boolean isEmployed() { return employed; }
    public void setEmployed(boolean employed) { this.employed = employed; }

    @Override
    public String getCustomerType() { return "Individual"; }
}
