package bank.model;

/** Implemented by accounts that earn interest (Savings, Investment). */
public interface InterestBearing {
    double calculateInterest();
    void payInterest();
}
