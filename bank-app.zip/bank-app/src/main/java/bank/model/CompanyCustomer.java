package bank.model;

public class CompanyCustomer extends Customer {
    private String companyName;
    private String registrationNo;

    public CompanyCustomer(String customerId, String address, String username, String plainPassword,
                           String companyName, String registrationNo) {
        super(customerId, address, username, plainPassword);
        this.companyName = companyName;
        this.registrationNo = registrationNo;
    }

    public String getCompanyName() { return companyName; }
    public String getRegistrationNo() { return registrationNo; }

    @Override
    public String getCustomerType() { return "Company"; }
}
