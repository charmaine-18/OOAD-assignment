package bank.model;

/** Implemented by accounts that allow withdrawals (Investment, Cheque). */
public interface Withdrawable {
    void withdraw(double amount);
}
