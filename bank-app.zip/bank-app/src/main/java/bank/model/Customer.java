package bank.model;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Customer {
    private final String customerId;
    private String address;
    private final String username;
    private String passwordHash;
    private final List<Account> accounts = new ArrayList<>();   // Customer 1 owns 1..* Account

    protected Customer(String customerId, String address, String username, String plainPassword) {
        this.customerId = customerId;
        this.address = address;
        this.username = username;
        this.passwordHash = hash(plainPassword);
    }

    /** Returns true if the supplied password matches the stored hash. */
    public boolean login(String pw) {
        return pw != null && passwordHash.equals(hash(pw));
    }

    public void addAccount(Account account) { accounts.add(account); }

    public List<Account> getAccounts() { return Collections.unmodifiableList(accounts); }

    public String getCustomerId() { return customerId; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getUsername() { return username; }
    public String getPasswordHash() { return passwordHash; }

    public abstract String getCustomerType();

    private static String hash(String text) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(text.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
