package bank.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Account implements Depositable {
    private final String accountNumber;
    private double balance;
    private final String branch;
    private final LocalDate openDate;
    private final List<Transaction> transactions = new ArrayList<>();   // Account 1 --- 0..* Transaction

    protected Account(String accountNumber, String branch, double openingBalance) {
        if (openingBalance < 0) {
            throw new IllegalArgumentException("Opening balance cannot be negative.");
        }
        this.accountNumber = accountNumber;
        this.branch = branch;
        this.openDate = LocalDate.now();
        this.balance = openingBalance;
        if (openingBalance > 0) {
            transactions.add(new Transaction("OPENING", openingBalance, balance));
        }
    }

    public double getBalance() { return balance; }
    public String getAccountNumber() { return accountNumber; }
    public String getBranch() { return branch; }
    public LocalDate getOpenDate() { return openDate; }

    public List<Transaction> getTransactions() {
        return Collections.unmodifiableList(transactions);
    }

    @Override
    public void deposit(double amount) {
        deposit(amount, "DEPOSIT");
    }

    /** The note becomes the transaction type, e.g. "INTEREST". */
    public void deposit(double amount, String note) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Deposit amount must be greater than zero.");
        }
        balance += amount;
        transactions.add(new Transaction(note, amount, balance));
    }

    /** Shared withdrawal logic for subclasses that implement Withdrawable. */
    protected void debit(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be greater than zero.");
        }
        if (amount > balance) {
            throw new InsufficientFundsException(
                    String.format("Insufficient funds: balance %.2f, requested %.2f", balance, amount));
        }
        balance -= amount;
        transactions.add(new Transaction("WITHDRAWAL", amount, balance));
    }

    public abstract String getAccountType();
}
