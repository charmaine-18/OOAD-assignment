package bank;

import bank.model.*;

/** Console demo of the core model only. Replaced by the JavaFX app in Week 5. */
public class Main {
    public static void main(String[] args) {
        IndividualCustomer thabo = new IndividualCustomer(
                "C001", "Plot 123, Gaborone", "thabo", "pass123", "Thabo", "Molefe", true);

        SavingsAccount savings = new SavingsAccount("S1001", "Main Mall", 1000);
        InvestmentAccount invest = new InvestmentAccount("I2001", "Main Mall", 500);
        ChequeAccount cheque = new ChequeAccount("CH3001", "Main Mall", 200,
                new Employer("Acme Ltd", "Gaborone"));
        thabo.addAccount(savings);
        thabo.addAccount(invest);
        thabo.addAccount(cheque);

        System.out.println("Login ok? " + thabo.login("pass123"));
        System.out.println("Login bad? " + thabo.login("wrong"));

        savings.deposit(500);
        savings.payInterest();
        cheque.withdraw(50);
        invest.withdraw(100);

        try {
            cheque.withdraw(10_000);
        } catch (InsufficientFundsException e) {
            System.out.println("Rejected: " + e.getMessage());
        }
        try {
            new InvestmentAccount("I2002", "Main Mall", 100);
        } catch (IllegalArgumentException e) {
            System.out.println("Rejected: " + e.getMessage());
        }

        for (Account a : thabo.getAccounts()) {
            System.out.printf("%n%s account %s, balance %.2f%n", a.getAccountType(), a.getAccountNumber(), a.getBalance());
            a.getTransactions().forEach(t -> System.out.println("  " + t));
        }
    }
}
